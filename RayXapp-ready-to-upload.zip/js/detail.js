(() => {
"use strict";
const $=s=>document.querySelector(s), esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
async function init(){
 const id=new URLSearchParams(location.search).get("id"), box=$("#detailContent");
 if(!id||!box){return;}
 const isAndroid=location.pathname.endsWith("app.html");
 const url=isAndroid?"data/android.json":"data/windows.json", key=isAndroid?"apps":"software";
 try{
  const r=await fetch(url,{cache:"no-store"}); if(!r.ok)throw Error();
  const data=await r.json(), item=(data[key]||[]).find(x=>x.id===id);
  if(!item){box.innerHTML='<div class="error-card"><h2>Not found</h2><p>This catalog entry does not exist.</p></div>';return;}
  const icon=String(item.icon||"").trim(), first=esc((item.name||"R").charAt(0).toUpperCase()), os=isAndroid?item.androidVersion:item.windowsVersion, dl=String(item.downloadUrl||"").trim();
  box.innerHTML=`<div class="detail-main"><div class="detail-icon">${icon?`<img src="${esc(icon)}" alt="" onerror="this.remove();this.parentElement.textContent='${first}'">`:first}</div><div>
   ${item.featured?'<span class="featured-badge">★ Featured</span>':""}<h1 class="detail-title">${esc(item.name)}</h1><div class="detail-sub">${esc(item.developer||"Unknown developer")} · v${esc(item.version||"—")}</div>
   <p class="detail-description">${esc(item.description||"No description available.")}</p>
   <div class="detail-meta"><div><small>Category</small><b>${esc(item.category||"other")}</b></div><div><small>Size</small><b>${esc(item.size||"—")}</b></div><div><small>Platform</small><b>${esc(os||"—")}</b></div></div>
   ${dl?`<a class="button primary" href="${esc(dl)}" target="_blank" rel="noopener noreferrer">Download ${isAndroid?"APK":""}</a>`:'<span class="button primary disabled">Download URL not available</span>'}
  </div></div>`;
  document.title=`${item.name} — RayXapp`;
 }catch(e){box.innerHTML='<div class="error-card"><h2>Unable to load</h2><p>Check the catalog JSON file on the server.</p></div>';}
}
document.addEventListener("DOMContentLoaded",init);
})();
(() => {
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function applyTheme(theme){
    const dark = theme === "dark";
    document.body.classList.toggle("dark", dark);
    localStorage.setItem("rayxapp-theme", dark ? "dark" : "light");
    const btn = $("#themeToggle");
    if(btn) btn.textContent = dark ? "☀" : "◐";
}
function initTheme(){
    const saved = localStorage.getItem("rayxapp-theme");
    applyTheme(saved || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
    $("#themeToggle")?.addEventListener("click", () => {
        applyTheme(document.body.classList.contains("dark") ? "light" : "dark");
    });
}
function initMenu(){
    const menu=$("#menuToggle"), nav=$("#mobileNav");
    if(!menu || !nav) return;
    menu.addEventListener("click",()=>nav.classList.toggle("open"));
    $$(".mobile-nav-link").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
}
function initBackTop(){
    const b=$("#backToTop"); if(!b)return;
    addEventListener("scroll",()=>b.classList.toggle("show",scrollY>500));
    b.addEventListener("click",()=>scrollTo({top:0,behavior:"smooth"}));
}
function initYear(){ $$("#currentYear").forEach(e=>e.textContent=new Date().getFullYear()); }
async function loadHomeCounts(){
    if(!$("#androidAppsGrid") && !$("#windowsAppsGrid")) return;
    try{
        const [a,w]=await Promise.all([fetch("data/android.json",{cache:"no-store"}),fetch("data/windows.json",{cache:"no-store"})]);
        const aj=await a.json(), wj=await w.json();
        const aa=Array.isArray(aj.apps)?aj.apps:[], ww=Array.isArray(wj.software)?wj.software:[];
        const ac=$("#heroAndroidCount"), wc=$("#heroWindowsCount");
        if(ac)ac.textContent=aa.length; if(wc)wc.textContent=ww.length;
        renderHome(aa,"androidAppsGrid","Android");
        renderHome(ww,"windowsAppsGrid","Windows");
        initHomeSearch([...aa.map(x=>({...x,platform:"android"})),...ww.map(x=>({...x,platform:"windows"}))]);
    }catch(e){
        ["androidAppsGrid","windowsAppsGrid"].forEach(id=>{const el=$("#"+id);if(el)el.innerHTML='<div class="error-card">Unable to load catalog data. Check the data/*.json files.</div>';});
    }
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function renderHome(items,id,platform){
    const el=$("#"+id); if(!el)return;
    const list=items.filter(x=>x.featured).slice(0,3).concat(items.filter(x=>!x.featured).slice(0,3)).slice(0,3);
    if(!list.length){el.innerHTML='<div class="empty-search">No entries yet.</div>';return;}
    el.innerHTML=list.map(x=>card(x,platform)).join("");
}
function card(x,platform){
    const icon=String(x.icon||"").trim(), first=esc((x.name||"R").charAt(0).toUpperCase());
    const href=platform==="Android"?`app.html?id=${encodeURIComponent(x.id)}`:`software.html?id=${encodeURIComponent(x.id)}`;
    const download=String(x.downloadUrl||"").trim();
    return `<article class="app-card" data-name="${esc(x.name)}" data-platform="${platform.toLowerCase()}">
      <div class="app-top"><div class="app-icon">${icon?`<img src="${esc(icon)}" alt="" onerror="this.remove();this.parentElement.textContent='${first}'">`:first}</div>
      <div><div class="app-name">${esc(x.name||"Unnamed")}</div><div class="app-developer">${esc(x.developer||"Unknown developer")}</div></div></div>
      <p class="app-description">${esc(x.description||"No description available.")}</p>
      <div class="app-meta"><span class="meta-pill">v${esc(x.version||"—")}</span><span class="meta-pill">${esc(x.size||"—")}</span><span class="meta-pill">${esc(x.category||"other")}</span>${x.featured?'<span class="featured-badge">★ Featured</span>':""}</div>
      <div class="app-actions"><a class="button secondary" href="${href}">Details</a>${download?`<a class="button primary" href="${esc(download)}" target="_blank" rel="noopener noreferrer">Download</a>`:'<span class="button primary disabled">No URL</span>'}</div>
    </article>`;
}
function initHomeSearch(all){
    const input=$("#appSearch"), clear=$("#clearSearch"), hints=$("#searchHints");
    if(!input)return;
    input.addEventListener("input",()=>{
        const q=input.value.trim().toLowerCase(); if(clear)clear.hidden=!q;
        if(!q){hints.innerHTML="";$$(".app-card").forEach(c=>c.hidden=false);return;}
        const matches=all.filter(x=>[x.name,x.developer,x.category,x.description].join(" ").toLowerCase().includes(q)).slice(0,6);
        hints.innerHTML=matches.map(x=>`<a href="${x.platform==="android"?"app":"software"}.html?id=${encodeURIComponent(x.id)}">${esc(x.name)} <small>· ${esc(x.platform)}</small></a>`).join("");
        $$(".app-card").forEach(c=>c.hidden=!c.dataset.name.toLowerCase().includes(q));
    });
    clear?.addEventListener("click",()=>{input.value="";input.dispatchEvent(new Event("input"));input.focus();});
}
document.addEventListener("DOMContentLoaded",()=>{initTheme();initMenu();initBackTop();initYear();loadHomeCounts();});
})();
(() => {
"use strict";
const $=s=>document.querySelector(s);
const esc=v=>String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const cfg=document.querySelector("#androidCatalogGrid")?{platform:"android",grid:"#androidCatalogGrid",search:"#androidSearch",clear:"#androidSearchClear",filter:"#androidFilters",empty:"#androidEmptySearch",url:"data/android.json",key:"apps",detail:"app"}:
document.querySelector("#windowsCatalogGrid")?{platform:"windows",grid:"#windowsCatalogGrid",search:"#windowsSearch",clear:"#windowsSearchClear",filter:"#windowsFilters",empty:"#windowsEmptySearch",url:"data/windows.json",key:"software",detail:"software"}:null;
if(!cfg)return;
let items=[];
function card(x){
 const icon=String(x.icon||"").trim(), first=esc((x.name||"R").charAt(0).toUpperCase()), url=String(x.downloadUrl||"").trim();
 const os=cfg.platform==="android"?x.androidVersion:x.windowsVersion;
 return `<article class="app-card" data-name="${esc(x.name)}" data-category="${esc(x.category||"other")}" data-developer="${esc(x.developer||"")}">
  <div class="app-top"><div class="app-icon">${icon?`<img src="${esc(icon)}" alt="" onerror="this.remove();this.parentElement.textContent='${first}'">`:first}</div><div><div class="app-name">${esc(x.name||"Unnamed")}</div><div class="app-developer">${esc(x.developer||"Unknown developer")}</div></div></div>
  <p class="app-description">${esc(x.description||"No description available.")}</p>
  <div class="app-meta"><span class="meta-pill">v${esc(x.version||"—")}</span><span class="meta-pill">${esc(x.size||"—")}</span><span class="meta-pill">${esc(os||"—")}</span><span class="meta-pill">${esc(x.category||"other")}</span>${x.featured?'<span class="featured-badge">★ Featured</span>':""}</div>
  <div class="app-actions"><a class="button secondary" href="${cfg.detail}.html?id=${encodeURIComponent(x.id)}">Details</a>${url?`<a class="button primary" href="${esc(url)}" target="_blank" rel="noopener noreferrer">Download ${cfg.platform==="android"?"APK":""}</a>`:'<span class="button primary disabled">No URL</span>'}</div>
 </article>`;
}
function render(){
 const q=($(cfg.search)?.value||"").trim().toLowerCase(), cat=($(cfg.filter)?.value||"all").toLowerCase();
 const filtered=items.filter(x=>{
   const hay=[x.name,x.version,x.category,x.developer,x.description].map(v=>String(v||"").toLowerCase()).join(" ");
   return (!q||hay.includes(q)) && (cat==="all"||String(x.category||"other").toLowerCase()===cat);
 });
 $(cfg.grid).innerHTML=filtered.length?filtered.map(card).join(""):`<div class="empty-search">No matching entries.</div>`;
 if($(cfg.empty))$(cfg.empty).hidden=filtered.length>0;
 if($(cfg.clear))$(cfg.clear).hidden=!q;
}
async function init(){
 try{
   const r=await fetch(cfg.url,{cache:"no-store"}); if(!r.ok)throw Error("HTTP "+r.status);
   const data=await r.json(); items=Array.isArray(data[cfg.key])?data[cfg.key]:Array.isArray(data)?data:[];
   render();
 }catch(e){$(cfg.grid).innerHTML='<div class="error-card">Unable to load this catalog. Check the JSON file and server path.</div>';return;}
 $(cfg.search)?.addEventListener("input",render); $(cfg.filter)?.addEventListener("change",render);
 $(cfg.clear)?.addEventListener("click",()=>{$(cfg.search).value="";render();$(cfg.search).focus();});
}
document.addEventListener("DOMContentLoaded",init);
})();
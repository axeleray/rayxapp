# RayXapp — upload package

Upload the CONTENTS of this folder to your hosting web root, normally `/htdocs/`.

Target structure:
- `/htdocs/index.html`
- `/htdocs/android.html`
- `/htdocs/windows.html`
- `/htdocs/app.html`
- `/htdocs/software.html`
- `/htdocs/categories.html`
- `/htdocs/about.html`
- `/htdocs/admin/index.html`
- `/htdocs/admin/admin.css`
- `/htdocs/css/...`
- `/htdocs/js/...`
- `/htdocs/data/android.json`
- `/htdocs/data/windows.json`
- `/htdocs/assets/...`

IMPORTANT:
1. Replace the example `downloadUrl` values in `data/android.json` and `data/windows.json` with real, authorized download URLs.
2. The current Admin Panel stores edits in browser LocalStorage. To publish those edits on a static host, use Admin > Data & Settings > Export, then upload the exported JSON to `/htdocs/data/`.
3. Do not upload APK/EXE files to RayXapp unless your hosting terms and your rights allow it.
4. The `assets/apps` and `assets/software` folders contain example SVG icons. Replace them with your real assets as needed.
5. Test the site through HTTP/HTTPS, not by opening the HTML files directly with `file://`, because the catalog uses fetch() for JSON.
